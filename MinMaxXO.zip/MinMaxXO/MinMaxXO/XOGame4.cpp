#include<iostream>
using namespace std;


int x, y;
bool draw = false;
bool loose = false;
bool win = false;
char board[4][4];
char tmpboard[4][4];
char comp;
char user;
int d = 0;
struct action{
	int row;
	int col;
	char XO;
};
struct state{
	action move;
	state* next;
};


action bestmove;
state* InsertAtQueue(state* head, char brd[4][4], char C, int row, int col){
	state*cur, *tmp;
	tmp = new state;
	if (tmp == NULL)
		exit(1);

	tmp->move.row = row;
	tmp->move.col = col;
	tmp->move.XO = C;
	tmp->next = NULL;
	if (head == NULL)
		return tmp;
	cur = head;
	while (cur->next != NULL)
		cur = cur->next;
	cur->next = tmp;
	return head;
}

state* Succersors(char brd[4][4], char C){
	state* head = new state;
	head = NULL;
	//find list of actions 
	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 4; j++){
			if (brd[i][j] == NULL){
				head = InsertAtQueue(head, brd, C, i, j);
			}

		}
	}

	return head;
}
bool CheckGoal(char brd[4][4]){
	bool full = true;
	bool empty = true;
	win = false;
	loose = false;
	draw = false;

	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 4; j++){
			if (brd[i][j] != NULL){
				empty = false;
				break;
			}
		}
		if (!empty)
			break;
	}

	if (empty)
		return false;


	for (int i = 0; i < 4; i++){
		if (brd[i][0] == comp && brd[i][1] == comp && brd[i][2] == comp && brd[i][3] == comp){
			win = true;
			return true;
		}
		if (brd[i][0] == user && brd[i][1] == user && brd[i][2] == user && brd[i][3] == user){
			loose = true;
			return true;
		}
	}

	for (int j = 0; j < 4; j++){
		if (brd[0][j] == comp && brd[1][j] == comp && brd[2][j] == comp && brd[3][j] == comp){
			win = true;
			return true;
		}
		if (brd[0][j] == user && brd[1][j] == user && brd[2][j] == user && brd[3][j] == user){
			loose = true;
			return true;
		}
	}
	if (brd[0][0] == comp && brd[1][1] == comp && brd[2][2] == comp && brd[3][3] == comp){
		win = true;
		return true;
	}
	if (brd[0][0] == user && brd[1][1] == user && brd[2][2] == user && brd[3][3] == user){
		loose = true;
		return true;
	}
	if (brd[0][2] == comp && brd[1][1] == comp && brd[2][0] == comp && brd[3][0] == comp){
		win = true;
		return true;
	}
	if (brd[0][2] == user && brd[1][1] == user && brd[2][0] == user && brd[3][0] == user){
		loose = true;
		return true;
	}


	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 4; j++){
			if (brd[i][j] == NULL){
				full = false;
				break;
			}
		}
		if (!full)
			break;
	}

	if (full){
		draw = true;
		return true;
	}

	return false;
}
int Eval(char brd[4][4]){
	int me = 0, opp = 0;
	if (CheckGoal(brd)){
		if (win)
			return 1000-d;
		else
		if (loose)
			return -1000-d;
		else if (draw)
			return 0;
	}
	else{
		for (int i = 0; i < 4; i++){
			if (brd[i][0] != comp && brd[i][1] != comp && brd[i][2] != comp && brd[i][3] != comp){
				opp++;
			}
			if (brd[i][0] != user && brd[i][1] != user && brd[i][2] != user && brd[i][3] != user){
				me++;
			}
		}

		for (int j = 0; j < 4; j++){
			if (brd[0][j] != comp && brd[1][j] != comp && brd[2][j] != comp  && brd[3][j] != comp){
				opp++;
			}
			if (brd[0][j] != user && brd[1][j] != user && brd[2][j] != user&& brd[3][j] != user){
				me++;
			}
		}
		if (brd[0][0] != comp && brd[1][1] != comp && brd[2][2] != comp && brd[3][3] != comp){
			opp++;
		}
		if (brd[0][0] != user && brd[1][1] != user && brd[2][2] != user && brd[3][3] != user){
			me++;
		}
		if (brd[0][3] != comp && brd[2][2] != comp && brd[1][1] != comp && brd[3][0] != comp){
			opp++;
		}
		if (brd[0][3] != user && brd[2][2] != user && brd[1][1] != user && brd[3][0] != user){
			me++;
		}

		return me - opp - d;
	}
}

bool checkValid(char brd[4][4], int x, int y){
	if (x > 3 || y > 3 || x < 0 || y < 0 )
		return false;
	else if (brd[x][y] != NULL)
		return false;
	else
		return true;
}


int MAX(int v, int minvalue, state* cur){
	int max;

	if (v >= minvalue){
		max = v;
	}
	else{
		max = minvalue;
	}

	return max;

}
int MIN(int v, int maxvalue){
	int min;

	if (v <= maxvalue){
		min = v;
	}
	else{
		min = maxvalue;
	}

	return min;

}


int MINVALUE(char brd[4][4]);
int MAXVALUE(char brd[4][4]);

action MinMax(char brd[4][4]){
	for (int i = 0; i < 4; i++){
		for (int j = 0; j < 4; j++){
			tmpboard[i][j] = board[i][j];

		}
	}


	bestmove.col = NULL;
	bestmove.row = NULL;
	bestmove.XO = NULL;
	int value = MAXVALUE(tmpboard);
	draw = false;
	loose = false;
	win = false;
	d = 0;

	return bestmove;
}

int main(){
	char ans = 'y';
	int turn = 0;
	do{
		//initial state 
		for (int i = 0; i < 4; i++){
			for (int j = 0; j < 4; j++){
				board[i][j] = NULL;

			}
		}
		if (turn == 1){
			user = 'O';
			comp = 'X';
			if (!CheckGoal(board)){
				MinMax(board);
				board[bestmove.row][bestmove.col] = bestmove.XO;
			}
		}

		do{
			cout << endl << "The Board: " << endl << endl;

			for (int j = 0; j < 4; j++){
				cout << "    " << j;

			}
			cout << endl << "    _______________" << endl;
			for (int i = 0; i < 4; i++){
				cout << " " << i;
				for (int j = 0; j < 4; j++){
					cout << " | " << board[i][j];

				}
				cout << " |" << endl << "    _______________" << endl;
			}
			cout << endl;
			do{
				cout << "Enter position : ex: 1 1 " << endl;
				cin >> x >> y;
			} while (!checkValid(board, x, y));


			if (turn == 0){
				board[x][y] = 'X';
				user = 'X';
				comp = 'O';
			}
			if (turn == 1){
				board[x][y] = 'O';
				user = 'O';
				comp = 'X';
			}

			if (!CheckGoal(board)){
				MinMax(board);
				board[bestmove.row][bestmove.col] = bestmove.XO;
			}


			system("cls");
		} while (!CheckGoal(board));
		cout << endl << endl;

		if (win){
			system("cls");
			cout << endl << "The Board: " << endl << endl;

			for (int j = 0; j < 4; j++){
				cout << "    " << j;

			}
			cout << endl << "    _______________" << endl;
			for (int i = 0; i < 4; i++){
				cout << " " << i;
				for (int j = 0; j < 4; j++){
					cout << " | " << board[i][j];

				}
				cout << " |" << endl << "    _______________" << endl;
			}
			cout << endl << endl;
			cout << "YOU LOOSE !!!";
			cout << endl << endl;
		}
		else
		if (loose){
			system("cls");
			cout << endl << "The Board: " << endl << endl;

			for (int j = 0; j < 4; j++){
				cout << "    " << j;

			}
			cout << endl << "    _______________" << endl;
			for (int i = 0; i < 4; i++){
				cout << " " << i;
				for (int j = 0; j < 4; j++){
					cout << " | " << board[i][j];

				}
				cout << " |" << endl << "    _______________" << endl;
			}
			cout << endl << endl;
			cout << "YOU WIN !!!";
			cout << endl << endl;
		}
		else
		if (draw){
			system("cls");
			cout << endl << "The Board: " << endl << endl;

			for (int j = 0; j < 4; j++){
				cout << "    " << j;

			}
			cout << endl << "    _______________" << endl;
			for (int i = 0; i < 4; i++){
				cout << " " << i;
				for (int j = 0; j < 4; j++){
					cout << " | " << board[i][j];

				}
				cout << " |" << endl << "    _______________" << endl;
			}
			cout << endl << endl;
			cout << "IT'S A DRAW !!!";
			cout << endl << endl;
		}

		if (turn == 0){
			turn = 1;
		}
		else if (turn == 1){
			turn = 0;
		}

		cout << endl;
		cout << "go for another n, y for yes :";
		cin >> ans;
		system("cls");
	} while (ans == 'y');

	system("pause");
	return 0;
}

int MAXVALUE(char brd[4][4]){
	int v, curV;
	if (CheckGoal(brd)){
		return Eval(brd);
	}




	v = -1001;
	curV = v;
	state* cur1 = new state;
	cur1 = NULL;
	cur1 = Succersors(brd, comp);
	d++;
	while (cur1 != NULL){
		brd[cur1->move.row][cur1->move.col] = cur1->move.XO;
		v = MAX(v, MINVALUE(brd), cur1);
		if (v > curV){
			curV = v;
			if (d == 1)
				bestmove = cur1->move;

		}
		brd[cur1->move.row][cur1->move.col] = NULL;
		cur1 = cur1->next;
	}

	d--;
	return v;
}

int MINVALUE(char brd[4][4]){
	int v;
	if (CheckGoal(brd)){
		return Eval(brd);
	}
	v = 1001;

	state* cur2 = new state;
	cur2 = NULL;
	cur2 = Succersors(brd, user);

	if (d < 3){
		while (cur2 != NULL){
			brd[cur2->move.row][cur2->move.col] = cur2->move.XO;
			v = MIN(v, MAXVALUE(brd));
			brd[cur2->move.row][cur2->move.col] = NULL;
			cur2 = cur2->next;
		}
	}
	else{
		while (cur2 != NULL){
		brd[cur2->move.row][cur2->move.col] = cur2->move.XO;
		v = MIN(v, Eval(brd));
		brd[cur2->move.row][cur2->move.col] = NULL;
		cur2 = cur2->next;
		}
	}

	return v;
}
