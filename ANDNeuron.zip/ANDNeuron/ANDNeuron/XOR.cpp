#include<iostream>
#include<cmath>
using namespace std;




int main(){

	int count = 0;
	int dOut[4] = { 0, 1, 1, 0 };
	double aOut[4];

	double w13 = 0.5, w14 = 0.9, w23 = 0.4, w24=1.0, w35=-1.2, w45=1.1;
	double y3[4], y4[4];


	float err[4];
	double theta3 = 0.8, theta4= -0.1, theta5 = 0.3;
	double alpha = 0.1;
	bool found = false;
	double inp1[4] = { 0, 0, 1, 1 };

	double inp2[4] = { 0, 1, 0, 1 };
	double grad3, grad4, grad5;



	do{
		count++;
		for (int i = 0; i < 4; i++)
		{
			/*double sum = (inp1[i] * iw1) + (inp2[i] * iw2) - theta;
			cout << inp1[i] * iw1 << " +  " << inp2[i] * iw2 << " - " << theta << endl;
			cout <<"sum :"<< sum << endl;*/

			y3[i] = 1 / (1 + exp(-(inp1[i] * w13 + inp2[i] * w23 - theta3)));
			y4[i] = 1 / (1 + exp(-(inp1[i] * w14 + inp2[i] * w24 - theta4)));


			aOut[i] = 1 / (1 + exp(-(y3[i] * w35 + y4[i] * w45 - theta5)));
			//cout << "aout :" << aOut[i] << endl;
			if (aOut[i] == dOut[i]){
				err[i] = 0;
			}
			else{
				err[i] = dOut[i] - aOut[i];
				grad5 = aOut[i] * (1 - aOut[i])*err[i];

				double diffw35 = alpha*y3[i] * grad5;
				double diffw45 = alpha*y4[i] * grad5;
				double difftheta5 = alpha*(-1) * grad5;

				grad3 = y3[i] * (1 - y3[i])*grad5*w35;
				grad4 = y4[i] * (1 - y4[i])*grad5*w45;

				double diffw13 = alpha*inp1[i] * grad3;
				double diffw23 = alpha*inp2[i] * grad3;
				double difftheta3 = alpha*(-1) * grad3;

				double diffw14 = alpha*inp1[i] * grad4;
				double diffw24 = alpha*inp2[i] * grad4;
				double difftheta4 = alpha*(-1) * grad4;

				w13 = w13 + diffw13;
				w14 = w14 + diffw14;

				w23 = w23 + diffw23;
				w24 = w24 + diffw24;

				w35 = w35 + diffw35;
				w45 = w45 + diffw45;

				theta3 = theta3 + difftheta3;
				theta4 = theta4 + difftheta4;
				theta5 = theta5 + difftheta5;


				//cout << "iw1 :" << iw1 << "iw2 :" << iw2 << endl;
			}
			if (i == 3){
				bool error = false;
				double sqr = 0;
				for (int j = 0; j < 4; j++)
				{
					//cout << "aOut : " << aOut[i] << "     and dOut is : " << dOut[i] << endl;
					 
					sqr += (err[j]*err[j]);
					
					if (j==3 && sqr>0.000005){
						error = true;
					}
				}
				if (!error){
					found = true;
				}
			}

		}
	} while (found == false);


	cout << "w13 :" << w13 << ", w23 : " << w23 << ", w14 : " << w14 << ", w24 : " << w24 << endl;
	cout << "w35 :" << w35 << ", w45 : " << w45 << ", theta3 : " << theta3 << ", theta4 : " << theta4 << ", theta5 : " << theta5 << endl;
	cout << "Epoch: " << count << endl;

	for (int i = 0; i < 4; i++)
	{
		y3[i] = 1 / (1 + exp(-(inp1[i] * w13 + inp2[i] * w23 - theta3)));
		y4[i] = 1 / (1 + exp(-(inp1[i] * w14 + inp2[i] * w24 - theta4)));


		aOut[i] = 1 / (1 + exp(-(y3[i] * w35 + y4[i] * w45 - theta5)));
		cout << "Input :" << inp1[i] << " " << inp2[i] << "  Output: " << aOut[i] << endl;
	}

	system("pause");
	return 0;
}