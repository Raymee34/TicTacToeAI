#include<iostream>
#include<cmath>
using namespace std;




int main(){

	int count = 0;
	int dOut[4] = { 0, 0, 0, 1 };
	int aOut[4];

	double iw1 = 0.3, iw2 = -0.1;

	float err[4];
	double theta = 0.2;
	double alpha = 0.1;
	bool found = false;
	int inp1[4] = { 0, 0, 1, 1 };

	int inp2[4] = { 0, 1, 0, 1 };


	do{
		count++;
		for (int i = 0; i < 4; i++)
		{
			/*double sum = (inp1[i] * iw1) + (inp2[i] * iw2) - theta;
			cout << inp1[i] * iw1 << " +  " << inp2[i] * iw2 << " - " << theta << endl;
			cout <<"sum :"<< sum << endl;*/
			aOut[i] = ((inp1[i] * iw1 + inp2[i] * iw2 - theta) >= 0 - 0.0001) ? 1 : 0;
			//cout << "aout :" << aOut[i] << endl;
			if (aOut[i] == dOut[i]){
				err[i] = 0;
			}
			else{
				err[i] = dOut[i] - aOut[i];
				iw1 = iw1 + (alpha*err[i] * inp1[i]);
				iw2 = iw2 + (alpha*err[i] * inp2[i]);
				//cout << "iw1 :" << iw1 << "iw2 :" << iw2 << endl;
			}
			if (i == 3){
				bool error = false;
				for (int i = 0; i < 4; i++)
				{
					//cout << "aOut : " << aOut[i] << "     and dOut is : " << dOut[i] << endl;
					if (err[i] != 0){
						error = true;
					}
				}
				if (!error){
					found = true;
				}
			}

		}
	} while (found == false);

	cout << "iw1 :" << iw1 << ", iw2 : " << iw2 << endl;
	cout << "Epoch: " << count << endl;


	system("pause");
	return 0;
}